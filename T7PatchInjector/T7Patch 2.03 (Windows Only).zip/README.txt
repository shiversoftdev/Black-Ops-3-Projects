discord.gg/gsc (not a support server)

Anti-Crash by Serious

Run the tool before starting your game. Leave the tool open while playing.

Options:
	Friends Only: Only allow friends to join you and info-request you. Best for solo streamers and players.
	Name Changer: Change your name so that stream watchers have a harder time finding out your XUID.
	Network Password: Set the password required to join you. Other patch users must share this password to join.
			  Note: This is the best option for solo players and streamers. This option is not compatible with online matchmaking.
	
Additional Info:

	This tool *does* protect you from many remote crashes and exploits. 
	
	This tool *does not* prevent people from getting your IP address when they are in the lobby with you.
	
	Do not attempt to use cheats with this tool. Most cheats are incompatible and your game will crash. 
	
	If your anti-virus deletes the file, add an exclusion. The tool is protected from reverse engineering to help deter cheaters from using the patch to develop new exploits.


Thanks to the following people for their help:
ssno
kai
ItsFebiven
SyGnUs
nice_sprite
Emma/IPG